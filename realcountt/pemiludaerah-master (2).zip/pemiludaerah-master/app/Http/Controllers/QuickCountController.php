<?php

namespace App\Http\Controllers;

use App\Candidate;
use Illuminate\Http\Request;

class QuickCountController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $candidates = Candidate::all();
        return view('welcome')->with(compact('candidates'));
    }

    public function update($id){
        $candidate = Candidate::find($id);
        $candidate->earned_value += 1;
        $candidate->save();

        return redirect()->route('index.vote')->with('message', 'Berhasil menambah 1 Suara pada '.$candidate->name.'!');
    }
}
